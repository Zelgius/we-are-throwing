OW_HEROES = ['ana', 'bastion', 'brigitte', 'doomfist', 'dva', 'genji',
             'hanzo', 'junkrat', 'lucio', 'mccree', 'mei', 'mercy',
             'moira', 'orisa', 'pharah', 'reaper', 'reinhardt', 'roadhog',
             'soldier76', 'sombra', 'symmetra', 'tracer', 'torbjorn',
             'winston', 'wrecking_ball', 'zarya', 'zenyatta']
